Little ChessPartner 1.08  - Januari 2003
----------------------------------------------

Before using this software be sure to read the license
agreement in the LICENSE.TXT file.


LCHESS has been the predecessor of ChessPartner, as a design study a Java version has been derived from it, this version is named: "Little ChessPartner".
Is has not been fully ported, just a small part of it ! A program written in Java is much slower then a program written in C or assembler, thus the playing strength will be much less as well. Note: This program is still under development, so please come back often, also feedback is appreciated.

The applet has been made freeware, you may download it and use it on your own website.
To use it download the zip file and place it in a directory on your web server.

Then on your page add something like this:

<applet
    code=jchess.class archive="http://yoururl/jchess.zip"
    name=jchess width=400 height=400>
</applet>

New in version 1.04 - Several parameters have been added to control some of the colors. 

<PARAM NAME="fen" VALUE="">

Optional starting position, value is a string in FEN format.

<PARAM NAME="bgcolor" VALUE="">

Optional background color.
    
<PARAM NAME="color" VALUE="">

Optional text color.

<PARAM NAME="whtfld" VALUE="">

Optional color of the white fields.

<PARAM NAME="blkfld" VALUE="">

Optional color of the black fields.

The color format is in hexadecimal  #RRGGBB

New in version 1.05 - Some parameters are added to control the board size. Be
aware if you use non standard board sizes the pieces are resized to fit the
board, this may not always give a good result

<PARAM NAME="brdwidth" VALUE="">

Width of the chessboard, default is 320

<PARAM NAME="brdheight" VALUE="">

height of the chessboard, default is 320

New in version 1.06 - Added parameters to control the text displayed on the
buttons. Intended for localizing the texts.

<PARAM NAME="but1txt" VALUE="Settings">

Text shown on button 1, default is "Settings"

<PARAM NAME="but2txt" VALUE="Move Now">

Text shown on button 2, default is "Move Now"

<PARAM NAME="but3txt" VALUE="New">

Text shown on button 3, default is "New"

<PARAM NAME="but4txt" VALUE="About">

Text shown on button 4, default is "About"

<PARAM NAME="msgline1txt" VALUE="depth={0} time={1} nodes={2} score={3}">

This controls the formating of the first line wich displays the depth etc.
The format string can have the parameters as shown in the sample e.g.
{0} - is the depth.

New in version 1.08 - Added some extra methods.

// sets the level
// type=type of level, 0=Fixed time, 1=fixed depth
// time is maximum thinking time in milliseconds
// dept is maximum search depth in ply's
boolean SetLevel(int type, int time, int depth);


// rotates the board
// flip - false = white at bottom
void FlipBoard(boolean flip);

// performs a move
// from is from field,
// to is to field.
// 0 is a1, 1=a2, 63=h8
boolean DoMove(int from,int to);
	
// Let computer start thinking.
boolean StartCompute();

// return true when the engine is busy thinking.
boolean IsBrainBusy();


// starts a new game
void NewGame();


// Forces engine to move immediately
void MoveNow();




// default level parameter
// See SetLevel method
<PARAM NAME="Level" VALUE="type,time,depth">

// Parameter to hide some of the buttons
// Bit flags  
//   1=settings
//   2=move now
//   4=new game
<PARAM NAME="HideButtons" VALUE="0">

// Rotates board
// See FlipBoard method
<PARAM NAME="flip" VALUE="0">

Default is 0 - white pieces below
           1 - black pieces below

New in version 1.07 - Added parameters to control generate script events.


<PARAM NAME="OnDoMove" VALUE="OnDomove">
<PARAM NAME="OnNewGame" VALUE="OnNewGame">

Name a Script event that gets called when a move is made on the board or a new
game is started.

Sample script:

<SCRIPT LANGUAGE="JavaScript">
function OnDomove(strMove)
{
	window.alert("OnDoMove(" + strMove + ")");
}
function OnNewGame()
{
	window.alert("OnNewGame");
}
</SCRIPT>

For security reasons, a Java applet and JavaScript can only communicate together
if they are allowed to. This is done easily by adding the MAYSCRIPT attribute to
the APPLET tag.


New property to set a position from JavaScript.

SetPosition(String fen)


Example with parameters:

<applet
    code=jchess.class archive="http://yoururl/jchess.zip"
    name=jchess width=400 height=400>
  <PARAM NAME="fen" VALUE="r2r2k1/p3nppp/8/1ppp2N1/8/4P3/PPPR1PPP/2KR4 b - - 0 1">
  <PARAM NAME="bgcolor" VALUE="#FFFFCC">
  <PARAM NAME="color" VALUE="#000080">
  <PARAM NAME="whtfld" VALUE="#E3C58C">
  <PARAM NAME="blkfld" VALUE="#955f22">
</applet>



If it does not work, don't complain, you get what you pay for :)

Note: Some browsers require the gif images to be placed outsite the zip file. In that case be sure to place them in the images subdirectory.

The ZIP contents:

0.gif
1.gif
10.gif
11.gif
2.gif
3.gif
4.gif
5.gif
6.gif
7.gif
8.gif
9.gif
readme.txt
jchess.html
Board.class
CEvar.class
CEvarNode.class
CEvarNodeHeader.class
ChessGame.class
ChsBoard.class
CSettingsDialog.class
CSList.class
DialogLayout.class
IChessGameCallback.class
IDD_SETTINGS.class
IMoveHandler.class
jchess.class
jchessFrame.class
MoveGen.class
MovesList.class
PieceSquareTables.class
Setup.class
license.txt


This applet can be used WITHOUT ANY WARRANTIES on your own risk.

For the latest updates check our website:

http://www.lokasoft.nl


Copyright (C) 2000-2003, Lokasoft
http://www.lokasoft.nl
rinfo@lokasoft.nl

